-- You can get the 2008 Credit sample database used in these demos 
-- from http://bit.ly/10fKpbS 

