SELECT @@SERVERNAME;

-- 1) Execute "Launch Replication Activity.cmd"

-- 2) Start up Replication Monitor

-- 3) Warnings tab and configuring alerts
	  -- Change latency warning to 3 seconds