
:CONNECT SQL2K12-SVR3
USE [CreditReporting];

DELETE  dbo.[category]
WHERE   [category_no] = 10; 
GO
